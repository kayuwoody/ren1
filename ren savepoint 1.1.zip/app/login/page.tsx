// app/login/page.tsx
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  const handleLogin = async () => {
    setError('');
    if (!input) return setError('Please enter your email or phone.');

    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ input }),
    });

    if (!res.ok) {
      setError('Login failed.');
      return;
    }

    const data = await res.json();
    localStorage.setItem('clientId', data.clientId);
    router.push('/orders');
  };

  return (
    <div className="max-w-md mx-auto p-6 space-y-4">
      <h1 className="text-2xl font-bold">Login or Register</h1>
      <input
        type="text"
        placeholder="Enter email or phone"
        className="w-full p-2 border rounded"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button
        className="bg-blue-600 text-white px-4 py-2 rounded w-full"
        onClick={handleLogin}
      >
        Continue
      </button>
      {error && <p className="text-red-600 text-sm">{error}</p>}
    </div>
  );
}
